var require = meteorInstall({"imports":{"api":{"Questions.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// imports/api/Questions.js                                                    //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
module.export({                                                                // 1
	Questions: function () {                                                      // 1
		return Questions;                                                            // 1
	}                                                                             // 1
});                                                                            // 1
var Meteor = void 0;                                                           // 1
module.watch(require("meteor/meteor"), {                                       // 1
	Meteor: function (v) {                                                        // 1
		Meteor = v;                                                                  // 1
	}                                                                             // 1
}, 0);                                                                         // 1
var Mongo = void 0;                                                            // 1
module.watch(require("meteor/mongo"), {                                        // 1
	Mongo: function (v) {                                                         // 1
		Mongo = v;                                                                   // 1
	}                                                                             // 1
}, 1);                                                                         // 1
var check = void 0;                                                            // 1
module.watch(require("meteor/check"), {                                        // 1
	check: function (v) {                                                         // 1
		check = v;                                                                   // 1
	}                                                                             // 1
}, 2);                                                                         // 1
var Questions = new Mongo.Collection("questions");                             // 5
                                                                               //
if (Meteor.isServer) {                                                         // 7
	// This code only runs on the server                                          // 8
	Meteor.publish('questions', function () {                                     // 9
		return Questions.find();                                                     // 10
	});                                                                           // 11
}                                                                              // 12
                                                                               //
Meteor.methods({                                                               // 14
	'questions.postQuestion': function (_ref) {                                   // 15
		var title = _ref.title,                                                      // 24
		    postedat = _ref.postedat,                                                // 24
		    theme = _ref.theme,                                                      // 24
		    votes = _ref.votes,                                                      // 24
		    answers = _ref.answers,                                                  // 24
		    text = _ref.text,                                                        // 24
		    userId = _ref.userId,                                                    // 24
		    poster = _ref.poster;                                                    // 24
		Questions.insert({                                                           // 25
			title: title,                                                               // 26
			postedat: postedat,                                                         // 27
			theme: theme,                                                               // 28
			votes: votes,                                                               // 29
			answers: answers,                                                           // 30
			text: text,                                                                 // 31
			userId: userId,                                                             // 32
			poster: poster                                                              // 33
		});                                                                          // 25
	},                                                                            // 35
	'questions.vote': function (_ref2) {                                          // 36
		var id = _ref2.id,                                                           // 36
		    vote = _ref2.vote;                                                       // 36
		var q = Questions.findOne(id);                                               // 37
		var votesToCast = vote === 'up' ? q.votes + 1 : q.votes - 1;                 // 38
		Questions.update(id, {                                                       // 39
			$set: {                                                                     // 40
				votes: votesToCast                                                         // 40
			}                                                                           // 40
		});                                                                          // 39
	},                                                                            // 42
	'questions.addAnswer': function (_ref3) {                                     // 43
		var id = _ref3.id,                                                           // 43
		    answers = _ref3.answers;                                                 // 43
		Questions.update(id, {                                                       // 44
			$push: answers                                                              // 46
		});                                                                          // 45
	}                                                                             // 48
});                                                                            // 14
/////////////////////////////////////////////////////////////////////////////////

},"Users.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// imports/api/Users.js                                                        //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
var Meteor = void 0;                                                           // 1
module.watch(require("meteor/meteor"), {                                       // 1
  Meteor: function (v) {                                                       // 1
    Meteor = v;                                                                // 1
  }                                                                            // 1
}, 0);                                                                         // 1
var Mongo = void 0;                                                            // 1
module.watch(require("meteor/mongo"), {                                        // 1
  Mongo: function (v) {                                                        // 1
    Mongo = v;                                                                 // 1
  }                                                                            // 1
}, 1);                                                                         // 1
var check = void 0;                                                            // 1
module.watch(require("meteor/check"), {                                        // 1
  check: function (v) {                                                        // 1
    check = v;                                                                 // 1
  }                                                                            // 1
}, 2);                                                                         // 1
var Accounts = void 0;                                                         // 1
module.watch(require("meteor/accounts-base"), {                                // 1
  Accounts: function (v) {                                                     // 1
    Accounts = v;                                                              // 1
  }                                                                            // 1
}, 3);                                                                         // 1
// Generate user initials after Facebook login                                 // 6
Accounts.onCreateUser(function (options, user) {                               // 7
  if (user.services.google) {                                                  // 8
    user.name = user.services.google.name;                                     // 9
    user.email = user.services.google.email;                                   // 10
    user.picture = user.services.google.picture;                               // 11
    user.isGoogle = true;                                                      // 12
  } else {                                                                     // 13
    user.name = user.username;                                                 // 14
    user.isGoogle = false;                                                     // 15
  }                                                                            // 16
                                                                               //
  user.questions = 0;                                                          // 17
  user.answers = 0; // We still want the default hook's 'profile' behavior.    // 18
                                                                               //
  if (options.profile) {                                                       // 20
    user.profile = options.profile;                                            // 21
  }                                                                            // 22
                                                                               //
  console.log(user); // Don't forget to return the new user object at the end!
                                                                               //
  return user;                                                                 // 25
});                                                                            // 26
Meteor.publish('user', function () {                                           // 28
  return Meteor.users.find(this.userId, {                                      // 30
    fields: {                                                                  // 31
      name: 1,                                                                 // 31
      email: 1,                                                                // 31
      picture: 1,                                                              // 31
      isGoogle: 1,                                                             // 31
      questions: 1,                                                            // 31
      answers: 1                                                               // 31
    }                                                                          // 31
  });                                                                          // 31
});                                                                            // 32
Meteor.methods({                                                               // 35
  'users.answers': function (_ref) {                                           // 36
    var userId = _ref.userId;                                                  // 36
    new SimpleSchema({                                                         // 37
      userId: {                                                                // 38
        type: String                                                           // 38
      }                                                                        // 38
    }).validate({                                                              // 37
      userId: userId                                                           // 39
    });                                                                        // 39
    var user = Meteor.users.findOne(userId);                                   // 40
    var answers = user.answers + 1;                                            // 41
    Meteor.users.update(userId, {                                              // 42
      $set: {                                                                  // 43
        answers: answers                                                       // 43
      }                                                                        // 43
    });                                                                        // 42
  },                                                                           // 45
  'users.questions': function (_ref2) {                                        // 46
    var userId = _ref2.userId;                                                 // 46
    new SimpleSchema({                                                         // 47
      userId: {                                                                // 48
        type: String                                                           // 48
      }                                                                        // 48
    }).validate({                                                              // 47
      userId: userId                                                           // 49
    });                                                                        // 49
    var user = Meteor.users.findOne(userId);                                   // 50
    var questions = user.questions + 1;                                        // 51
    Meteor.users.update(userId, {                                              // 52
      $set: {                                                                  // 53
        questions: questions                                                   // 53
      }                                                                        // 53
    });                                                                        // 52
  }                                                                            // 55
});                                                                            // 35
/////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////
//                                                                             //
// server/main.js                                                              //
//                                                                             //
/////////////////////////////////////////////////////////////////////////////////
                                                                               //
var Meteor = void 0;                                                           // 1
module.watch(require("meteor/meteor"), {                                       // 1
  Meteor: function (v) {                                                       // 1
    Meteor = v;                                                                // 1
  }                                                                            // 1
}, 0);                                                                         // 1
module.watch(require("../imports/api/Questions.js"));                          // 1
module.watch(require("../imports/api/Users.js"));                              // 1
Meteor.startup(function () {// code to run on server at startup                // 5
});                                                                            // 7
/////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});
require("./server/main.js");
//# sourceMappingURL=app.js.map
